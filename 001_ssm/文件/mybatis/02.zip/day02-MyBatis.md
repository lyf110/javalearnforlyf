---
typora-copy-images-to: img
---

# day02-MyBatis

## 学习目标

+ 掌握Mybatis框架的基本CRUD操作
+ 掌握Mybatis的参数深入
+ 掌握Mybatis的DAO层开发
+ 掌握SqlMapConfig.xml配置文件 


## 一,日志系统的介绍【会用就行】 

### 1.概述 

​	我们在使用MyBatis的时候, 其实MyBatis框架会打印一些必要的日志信息, 在开发阶段这些日志信息对我们分析问题,理解代码的执行是特别有帮助的; 包括项目上线之后,我们也可以收集项目的错误日志到文件里面去;  所有我们采用专门的日志系统来处理.

### 2.日志的使用步骤

- 导入坐标

```xml
<dependency>
     <groupId>log4j</groupId>
     <artifactId>log4j</artifactId>
     <version>1.2.12</version>
</dependency>
```

- 在resources目录下编写log4j.properties配置文件

```properties
##设置日志记录到控制台的方式
log4j.appender.std=org.apache.log4j.ConsoleAppender
log4j.appender.std.Target=System.err
log4j.appender.std.layout=org.apache.log4j.PatternLayout
log4j.appender.std.layout.ConversionPattern=%d{yyyy-MM-dd HH:mm:ss} %5p %c{1}:%L - %m%n

##设置日志记录到文件的方式
log4j.appender.file=org.apache.log4j.FileAppender
log4j.appender.file.File=mylog.txt
log4j.appender.file.layout=org.apache.log4j.PatternLayout
log4j.appender.file.layout.ConversionPattern=%d{ABSOLUTE} %5p %c{1}:%L - %m%n

##日志输出的级别，以及配置记录方案
log4j.rootLogger= info,std,file	
```

  级别:error > warn > info>debug>trace  

## 二,Mybatis 框架实现 CRUD 操作【重点】 

### 1.完成MyBatis的CRUD

#### 1.1新增用户

##### 1.1.1实现步骤

+ UserDao中添加新增方法 

```java
public interface UserDao {
    /**
     * 保存用户
     * @param user
     */
    void save(User user);
}
```

+ 在 UserDao.xml 文件中加入新增配置 

```xml
    <insert id="save" parameterType="com.itheima.bean.User">
        INSERT INTO t_user(username,sex,birthday,address) VALUES (#{username},#{sex},#{birthday},#{address})
    </insert>

	<!--我们可以发现， 这个 sql 语句中使用#{}字符， #{}代表占位符，我们可以理解是原来 jdbc 部分所学的?，它们都是代表占位符， 具体的值是由 User 类的 username 属性来决定的。
	parameterType 属性：代表参数的类型，因为我们要传入的是一个类的对象，所以类型就写类的
全名称。-->
```

+ 添加测试类中的测试方法 

```java
    @Test
    public void fun02() throws Exception {
        //1. 读取SqlMapConfig.xml获得输入流
        InputStream is = Resources.getResourceAsStream("SqlMapConfig.xml");
        //2.创建SqlSessionFactory
        SqlSessionFactoryBuilder builder = new SqlSessionFactoryBuilder();
        SqlSessionFactory sqlSessionFactory = builder.build(is);
        //3. 获得SqlSession
        SqlSession sqlSession = sqlSessionFactory.openSession();
        //4.获得UserDao代理对象
        UserDao userDao = sqlSession.getMapper(UserDao.class);

        //5.调用方法
        User user = new User("赵六","男",new Date(),"广州");
        userDao.save(user);
        sqlSession.commit();

        //6.释放资源
        sqlSession.close();
    }
```

##### 1.1.2新增用户 id 的返回值 

​	新增用户后， 同时还要返回当前新增用户的 id 值，因为 id 是由数据库的自动增长来实现的，所以就相当于我们要在新增后将自动增长 auto_increment 的值返回。 

+  方式一 SelectKey获取主键

| **属性**      | **描述**                                   |
| ----------- | ---------------------------------------- |
| keyProperty | selectKey 语句结果应该被设置的目标属性。                |
| resultType  | 结果的类型。MyBatis 通常可以算出来,但是写上也没有问题。MyBatis 允许任何简单类型用作主键的类型,包括字符串。 |
| order       | 这可以被设置为 BEFORE 或 AFTER。如果设置为 BEFORE,那么它会首先选择主键,设置 keyProperty 然后执行插入语句。如果设置为 AFTER,那么先执行插入语句,然后是 selectKey 元素-这和如  Oracle 数据库相似,可以在插入语句中嵌入序列调用。 |

  UserDao.xml

```xml
    <!--parameterType属性: 参数的类型 ;  赋值的时候直接写对象里面的属性名-->
    <insert id="save" parameterType="com.itheima.bean.User">
        <!--presultType: 主键类型; keyProperty:pojo里面对应的id的属性名; order属性: 指定是在目标的sql语句之前还是之后执行 -->
        <selectKey resultType="int" keyProperty="uid" order="AFTER">
            SELECT LAST_INSERT_ID()
        </selectKey>
        INSERT INTO t_user(username,sex,birthday,address)VALUES(#{username},#{sex},#{birthday},#{address})
    </insert>
```

+ 方式二属性配置

  UserDao.xml

```xml
<insert id="save" parameterType="com.itheima.bean.User" keyProperty="uid" useGeneratedKeys="true">
        INSERT INTO t_user(username,sex,birthday,address) VALUES (#{username},#{sex},#{birthday},#{address})
    </insert>
```

##### 1.1.3新增用户 id 的返回值(字符串类型)

```xml
<insert id="save" parameterType="com.itheima.bean.User">
    <selectKey  keyProperty="id" resultType="string" order="BEFORE">
        select uuid()
    </selectKey>
        INSERT INTO t_user(username,sex,birthday,address) VALUES (#{username},#{sex},#{birthday},#{address})
</insert>
```

#### 1.2修改用户

- UserDao中添加新增方法 

```java
public interface UserDao {
    /**
     * 更新用户
     * @param user
     */
    void  update(User user);
}
```

- 在 UserDao.xml 文件中加入新增配置 

```xml
<update id="update" parameterType="com.itheima.bean.User">
    UPDATE t_user SET username=#{username},sex=#{sex},birthday=#{birthday},address=#{address} WHERE uid=#{uid}
</update>
```

- 添加测试类中的测试方法 

```java
    @Test
    public void fun03() throws Exception {
        InputStream is = Resources.getResourceAsStream("SqlMapConfig.xml");
        SqlSessionFactoryBuilder builder = new SqlSessionFactoryBuilder();
        SqlSessionFactory sqlSessionFactory = builder.build(is);
        SqlSession sqlSession = sqlSessionFactory.openSession();
        UserDao userDao = sqlSession.getMapper(UserDao.class);

        User user = new User("王二","女",new Date(),"广州");
        user.setUid(11);
        userDao.update(user);

        sqlSession.commit();
        sqlSession.close();
    }
```

#### 1.3删除用户

- UserDao中添加新增方法 

```java
public interface UserDao {

    /**
     * 删除用户
     * @param uid
     */
    void delete(int uid);
}
```

- 在 UserDao.xml 文件中加入新增配置 

```xml
<delete id="delete" parameterType="int">
    DELETE FROM t_user WHERE uid = #{uid}
</delete>
```

- 添加测试类中的测试方法 

```java
    @Test
    public void fun04() throws Exception {
        InputStream is = Resources.getResourceAsStream("SqlMapConfig.xml");
        SqlSessionFactoryBuilder builder = new SqlSessionFactoryBuilder();
        SqlSessionFactory sqlSessionFactory = builder.build(is);
        SqlSession sqlSession = sqlSessionFactory.openSession();
        UserDao userDao = sqlSession.getMapper(UserDao.class);

        userDao.delete(11);

        sqlSession.commit();
        sqlSession.close();
    }
```

#### 1.4模糊查询

##### 1.4.1 方式一

- UserDao 中添加新增方法 

```java
public interface UserDao {
    /**
     * 模糊查询
     * @param firstName
     * @return
     */
    List<User> findByFirstName(String firstName);
}
```

- 在 UserDao.xml 文件中加入新增配置 

```xml
<select id="findByFirstName" parameterType="string" resultType="com.itheima.bean.User">
  	SELECT * FROM t_user WHERE username LIKE #{firstName}
</select>
```

- 添加测试类中的测试方法 

```java
    @Test
    public void fun05() throws Exception {
        InputStream is = Resources.getResourceAsStream("SqlMapConfig.xml");
        SqlSessionFactoryBuilder builder = new SqlSessionFactoryBuilder();
        SqlSessionFactory sqlSessionFactory = builder.build(is);
        SqlSession sqlSession = sqlSessionFactory.openSession();
        UserDao userDao = sqlSession.getMapper(UserDao.class);

        List<User> list = userDao.findByFirstName("王%");
        System.out.println(list);

        sqlSession.commit();
        sqlSession.close();
    }
```

##### 1.4.2 方式二

- UserDao 中添加新增方法 

```java
public interface UserDao {
    /**
     * 模糊查询
     * @param firstName
     * @return
     */
    List<User> findByFirstName02(String firstName);
}
```

- 在 UserMapper.xml 文件中加入新增配置 

```xml
    <select id="findByFirstName02" parameterType="string" resultType="com.itheima.bean.User">
        SELECT * FROM t_user WHERE username LIKE '${value}%'
    </select>
```

​	` 我们在上面将原来的#{}占位符，改成了${value}。注意如果用模糊查询的这种写法，那么${value}的写法就是固定的，不能写成其它名字。` 

- 添加测试类中的测试方法 

```java
    @Test
    public void fun06() throws Exception {
        InputStream is = Resources.getResourceAsStream("SqlMapConfig.xml");
        SqlSessionFactoryBuilder builder = new SqlSessionFactoryBuilder();
        SqlSessionFactory sqlSessionFactory = builder.build(is);
        SqlSession sqlSession = sqlSessionFactory.openSession();
        UserDao userDao = sqlSession.getMapper(UserDao.class);

        List<User> list = userDao.findByFirstName02("王");
        System.out.println(list);

        sqlSession.commit();
        sqlSession.close();
    }
```

##### 1.4.3 #{}与${}的区别【面试】

```
1.#{}表示一个占位符号
	通过#{}可以实现 preparedStatement 向占位符中设置值
	自动进行 java 类型和 数据库 类型转换 
    #{}可以有效防止 sql 注入 
    #{}可以接收简单类型值或 pojo 属性值
    如果 parameterType 传输单个简单类型值， #{}括号中可以是 value 或其它名称。
2.${}表示拼接 sql 串
	通过${}可以将 parameterType 传入的内容拼接在 sql 中且不进行 jdbc 类型转换. 
	${}可以接收简单类型值或 pojo 属性值，
	如果 parameterType 传输单个简单类型值.${}括号中只能是 value
	不能防止 sql 注入 
```

### 2.SqlSessionFactory工具类的抽取

```java
public class SqlSessionFactoryUtils {

    public static SqlSessionFactory sqlSessionFactory;

    static{
        InputStream is = null;
        try {
            //读取SqlMapConfig
            is = Resources.getResourceAsStream("SqlMapConfig.xml");
            //构建sqlSessionFactory
            SqlSessionFactoryBuilder builder = new SqlSessionFactoryBuilder();
            sqlSessionFactory = builder.build(is);
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            if (is != null) {
                try {
                    is.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

    }
    /**
     * 获得Session
     * @return
     */
    public static SqlSession openSession(){
        SqlSession sqlSession = sqlSessionFactory.openSession();
        return  sqlSession;
    }
}
```

## 三,Mybatis 的参数深入【掌握】 

​	Mybatis 的映射文件其实就是与 DAO 相对应，因为 DAO 中的方法有参数及返回值，那么在Mybatis 的映射文件中自然也就有与之对应的参数和返回结果。在 Mybatis 的映射文件中参数用 parameterType 来代表，它的值可以是基本类型，也可以是包装的对象，这一点我们上面学习中就使用过。在 Mybatis 的映射文件中返回结果用 resultType 和resultMap 来代表 .

### 1. parameterType(输入/参数类型)  

#### 1.1传递简单类型

​	基本的类型,字符串

​	直接写#{任意字段}或者${value}

![1535099951604](img/1535099951604.png)

#### 1.2传递 pojo 对象 

​	Mybatis 使用 ognl 表达式解析对象字段的值， #{}或者${}括号中的值为 pojo 属性名称。 

![1535100050378](img/1535100050378.png)

#### 1.3传递 pojo 包装对象类型 

​	开发中通过 pojo 传递查询条件 ，查询条件是综合的查询条件，不仅包括用户查询条件还包括其它的查询条件（比如将用户购买商品信息也作为查询条件），这时可以使用包装对象传递输入参数。Pojo 类中包含 pojo。

​	京东查询的例子:

![1539830569011](img/1539830569011.png)

​	需求：根据用户id查询用户信息，查询条件放到 QueryVo 的 user 属性中。 

+ QueryVo  

```java
public class QueryVo {

    private User user;

    public void setUser(User user) {
        this.user = user;
    }

    public User getUser() {
        return user;
    }
}
```

+ UserDao接口 

```java
public interface UserDao {
    /**
     * 复杂参数查询
     * @return
     */
    List<User> findByQueryVo(QueryVo queryVo);

}
```

+ UserDao.xml文件 

```xml
<mapper namespace="com.itheima.dao.UserDao">
    <select id="findByQueryVo" resultType="com.itheima.bean.User" parameterType="com.itheima.bean.QueryVo">
        SELECT * FROM t_user WHERE uid > #{user.uid}
    </select>
</mapper>
```

+ 测试代码

```java
   @Test
    public void fun01() throws Exception {
        SqlSession sqlSession = SqlSessionFactoryUtils.openSession();
        UserDao userDao = sqlSession.getMapper(UserDao.class);

        QueryVo queryVo = new QueryVo();
        User user = new User();
        user.setUid(2);
        queryVo.setUser(user);
        List<User> list = userDao.findByQueryVo(queryVo);
        System.out.println(list);

        sqlSession.close();
    }
```

### 2. resultType(输出/返回类型)  

#### 2.1输出简单类型

​	直接写对应的Java类型. eg: 返回int

```xml
<select id="findCount" parameterType="int" resultType="int">
     SELECT  COUNT(*) FROM t_user
</select>
```

#### 2.2输出pojo对象

​	直接写当前pojo类的全限定名 eg: 返回User

```xml
<select id="findByUid" parameterType="int" resultType="com.itheima.bean.User">
        select * from t_user where uid = #{uid}
</select>
```

#### 2.3输出pojo列表

​	直接写当前pojo类的全限定名 eg: 返回 List<User> list;

```xml
<select id="findAll" resultType="com.itheima.bean.User">
        select * from t_user
</select>
```

### 3.resultMap结果类型 

       resultType可以指定pojo将查询结果映射为pojo，但需要pojo的属性名和sql查询的列名一致方可映射成功。

       如果==sql查询字段名和pojo的属性名==不一致，可以通过resultMap将字段名和属性名作一个对应关系 ，resultMap实质上还需要将查询结果映射到pojo对象中。

    	resultMap可以==实现将查询结果映射为复杂类型的pojo==，比如在查询结果映射对象中包括pojo和list实现一对一查询和一对多查询。(下次课讲)

#### 3.1 实例

​	那我们今天就来看返回的列名与实体类的属性不一致时的情况. 下次课再接着研究复杂的封装(多表查询)

​	通过改别名的方式，现在返回结果集的列名已经与 User 类的属性名不相同了。 

```sql
select uid uid_,username username_ ,birthday birthday_ ,sex sex_ ,address address_  from t_user where uid = #{id}
```

+ UserDao.java

```java
public interface UserDao {
    /**
     * 根据uid查询
     * @param uid
     * @return
     */
    User findByUid(int uid);

}
```

+ UserDao.xml

```xml
    <select id="findByUid" parameterType="int" resultMap="findByUidMap">
        select uid uid_,username username_ ,birthday birthday_ ,sex sex_ ,address address_  from t_user where uid = #{id}
    </select>

    <resultMap id="findByUidMap" type="com.itheima.bean.User">
        <id property="uid" column="uid_"></id>
        <result property="username" column="username_"></result>
        <result property="birthday" column="birthday_"></result>
        <result property="sex" column="sex_"></result>
        <result property="address" column="address_"></result>
    </resultMap>
<!-- 
id：此属性表示查询结果集的唯一标识，非常重要。如果是多个字段为复合唯一约束则定义多个id。
type: 当前resultMap封装后返回的结果
property：表示 User 类的属性。
column：表示 sql 查询出来的字段名。(column 和 property 放在一块儿表示将 sql 查询出来的字段映射到指定的 pojo 类属性上。)
-->
```

## 四,Mybatis 实现 DAO 层开发 

​	使用 Mybatis开发 Dao，通常有两个方法，即原始 Dao 开发方式和 Mapper 接口代理开发方式。 而现在主流的开发方式是接口代理开发方式，这种方式总体上更加简便。 我们的课程讲解也主要以接口代理开发方式为主。 

### 1.原始的dao开发【了解】 

#### 1.1映射文件

```xml
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE mapper
        PUBLIC "-//mybatis.org//DTD Mapper 3.0//EN"
        "http://mybatis.org/dtd/mybatis-3-mapper.dtd">
<mapper namespace="test">
    <select id="findAll" resultType="com.itheima.bean.User">
        SELECT *FROM t_user
    </select>

    <insert id="save" parameterType="com.itheima.bean.User" keyProperty="uid" useGeneratedKeys="true">
        INSERT INTO t_user(username,sex,birthday,address) VALUES (#{username},#{sex},#{birthday},#{address})
    </insert>
    
    <update id="update" parameterType="com.itheima.bean.User">
        UPDATE t_user SET username=#{username},sex=#{sex},birthday=#{birthday},address=#{address} WHERE uid=#{uid}
    </update>

    <delete id="delete" parameterType="int">
        DELETE FROM t_user WHERE uid = #{uid}
    </delete>

    <select id="findByFirstName" parameterType="string" resultType="com.itheima.bean.User">
        SELECT * FROM t_user WHERE username LIKE #{firstName}
    </select>

    <select id="findByFirstName02" parameterType="string" resultType="com.itheima.bean.User">
        SELECT * FROM t_user WHERE username LIKE '${value}%'
    </select>
</mapper>
```

#### 1.2UserDao

+ UserDao.java

```java
public interface UserDao {

    List<User> findAll();

    /**
     * 保存用户
     * @param user
     */
    void save(User user);

    /**
     * 更新用户
     * @param user
     */
    void  update(User user);

    /**
     * 删除用户
     * @param uid
     */
    void delete(int uid);

    /**
     * 模糊查询
     * @param firstName
     * @return
     */
    List<User> findByFirstName(String firstName);

    /**
     * 模糊查询
     * @param firstName
     * @return
     */
    List<User> findByFirstName02(String firstName);
}
```

+ UserDaoImpl.java

```java
public class UserDaoImpl implements UserDao {

    @Override
    public List<User> findAll() {

        SqlSession sqlSession = SqlSessionFactoryUtils.openSession();
        List<User> list = sqlSession.selectList("test.findAll");
        sqlSession.close();
        return list;
    }

    /**
     * 保存用户
     *
     * @param user
     */
    @Override
    public void save(User user) {
        SqlSession sqlSession = SqlSessionFactoryUtils.openSession();
        sqlSession.insert("test.save",user);
        sqlSession.commit();
        sqlSession.close();

    }

    /**
     * 更新用户
     * @param user
     */
    @Override
    public void update(User user) {
        SqlSession sqlSession = SqlSessionFactoryUtils.openSession();
        sqlSession.update("test.update",user);
        sqlSession.commit();
        sqlSession.close();

    }

    /**
     * 删除用户
     *
     * @param uid
     */
    @Override
    public void delete(int uid) {
        SqlSession sqlSession = SqlSessionFactoryUtils.openSession();
        sqlSession.delete("test.delete",uid);
        sqlSession.commit();
        sqlSession.close();


    }

    /**
     * 模糊查询
     *
     * @param firstName
     * @return
     */
    @Override
    public List<User> findByFirstName(String firstName) {
        SqlSession sqlSession = SqlSessionFactoryUtils.openSession();
        List<User> list = sqlSession.selectList("test.findByFirstName",firstName);
        sqlSession.close();
        return list;
    }

    /**
     * 模糊查询
     *
     * @param firstName
     * @return
     */
    @Override
    public List<User> findByFirstName02(String firstName) {
        SqlSession sqlSession = SqlSessionFactoryUtils.openSession();
        List<User> list = sqlSession.selectList("test.findByFirstName02",firstName);
        sqlSession.close();
        return list;
    }
}
```

#### 1.3测试代码

```java
public class DbTest {
    @Test
    public void fun01() throws Exception {
        UserDao userDao = new UserDaoImpl();
        List<User> list = userDao.findAll();
        System.out.println(list);
    }


    @Test
    public void fun02() throws Exception {
        UserDao userDao = new UserDaoImpl();

        User user = new User();
        user.setUsername("ls");
        user.setSex("男");
        user.setBirthday(new Date());
        user.setAddress("北京");

        userDao.save(user);
    }

    @Test
    public void fun03() throws Exception {
        UserDao userDao = new UserDaoImpl();

        User user = new User();
        user.setUid(12);
        user.setUsername("zs");
        user.setSex("女");
        user.setBirthday(new Date());
        user.setAddress("北京");

        userDao.update(user);
    }

    @Test
    public void fun04() throws Exception {
        UserDao userDao = new UserDaoImpl();
        userDao.delete(12);
    }

    @Test
    public void fun05() throws Exception {
        UserDao userDao = new UserDaoImpl();
        List<User> list = userDao.findByFirstName("王%");
        System.out.println(list);
    }

    @Test
    public void fun06() throws Exception {
        UserDao userDao = new UserDaoImpl();
        List<User> list = userDao.findByFirstName02("王");
        System.out.println(list);
    }
}
```

#### 1.4问题

- 调用sqlSession的数据库操作方法需要指定statement的id，这里存在硬编码，不便于维护

### 2.Mapper动态代理方式【掌握】

#### 2.1开发规范

​	Mapper接口开发方法只需要程序员编写Mapper接口（相当于Dao接口），由Mybatis框架根据接口定义创建接口的动态代理对象，代理对象的方法体同上边Dao接口实现类方法。

#### 2.2Mapper.xml(映射文件)

​	定义mapper映射文件UserDao.xml，需要修改namespace的值为 UserDao接口全限定名。将UserDao.xml放在classpath的xxx.xxx.dao目录下

```xml
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE mapper
        PUBLIC "-//mybatis.org//DTD Mapper 3.0//EN"
        "http://mybatis.org/dtd/mybatis-3-mapper.dtd">
<mapper namespace="com.itheima.dao.UserDao">
    <select id="findAll" resultType="User">
        SELECT *FROM t_user
    </select>

    <insert id="save" parameterType="com.itheima.bean.User" keyProperty="uid" useGeneratedKeys="true">
        INSERT INTO t_user(username,sex,birthday,address) VALUES (#{username},#{sex},#{birthday},#{address})
    </insert>
</mapper>
```

#### 2.3Mapper.java(dao接口)

Mapper接口开发需要遵循以下规范： 

1、 Mapper.xml文件中的namespace必须和mapper(Dao)接口的全限定名相同。

2、Mapper.xml文件中select,update等的标签id的值必须和mapper(Dao)接口的方法名相同

3、Mapper.xml文件中select,update等的标签的parameterType必须和mapper(Dao)接口的方法的形参类型对应

4, Mapper.xml文件中select,update等的标签的resultType必须和mapper(Dao)接口的方法的返回值类型对应

5,  Mapper.xml文件的文件名尽量和mapper(Dao)接口的名字一样

6, Mapper.xml文件的路径尽量和mapper(Dao)接口的路径在同一层目录

```java
public interface UserDao {

    /**
     * 查询所有的用户
     * @return
     */
    List<User> findAll();

    /**
     * 保存用户
     * @param user
     */
    void save(User user);
}
```

#### 2.4测试

```java
public class DbTest {

      @Test
    public void fun01() throws Exception {
        SqlSession sqlSession = SqlSessionFactoryUtils.openSession();
        //4.获得UserDao代理对象
        UserDao userDao = sqlSession.getMapper(UserDao.class);
        //5.调用方法
        List<User> list = userDao.findAll();
        System.out.println(list);
        //6.释放资源
        sqlSession.close();
    }

    @Test
    public void fun02() throws Exception {
        SqlSession sqlSession = SqlSessionFactoryUtils.openSession();
        UserDao userDao = sqlSession.getMapper(UserDao.class);

        User user = new User("王二麻子","男",new Date(),"广州");
        userDao.save(user);
        sqlSession.commit();

        sqlSession.close();
    }

}
```

## 五.核心配置文件mybatis.xml【掌握】

### 1.核心配置文件的顺序

**properties（引入外部properties文件）**

settings（全局配置参数）

**typeAliases（类型别名）**

typeHandlers（类型处理器）

objectFactory（对象工厂）

plugins（插件）

**environments（环境集合属性对象）**

​	environment（环境子属性对象）

​		transactionManager（事务管理）

​		dataSource（数据源）

**mappers（映射器）**

### 2.properties

- jdbc.properties

```properties
jdbc.driver=com.mysql.jdbc.Driver
jdbc.url=jdbc:mysql://localhost:3306/mybatis_day01?characterEncoding=utf-8
jdbc.user=root
jdbc.password=123456
```

- 引入到核心配置文件

```xml
<configuration>
   <properties resource="jdbc.properties">
    </properties>
    <!--数据源配置-->
    <environments default="development">
        <environment id="development">
            <transactionManager type="JDBC"/>
            <dataSource type="UNPOOLED">
                <property name="driver" value="${jdbc.driver}"/>
                <property name="url" value="${jdbc.url}"/>
                <property name="username" value="${jdbc.user}"/>
                <property name="password" value="${jdbc.password}"/>
            </dataSource>
        </environment>
    </environments>
    ....
</configuration>
```

### 3.typeAliases（类型别名）

#### 3.1定义单个别名

- 核心配置文件

```xml
<typeAliases>
      <typeAlias type="com.itheima.bean.User" alias="user"></typeAlias>
 </typeAliases>
```

- 修改UserDao.xml

```java
<select id="findAll" resultType="user">
    SELECT  * FROM  user
</select>
```

#### 3.2批量定义别名

使用package定义的别名：就是pojo的类名，大小写都可以

- 核心配置文件

```xml
<typeAliases>
    <package name="com.itheima.bean"/>
</typeAliases>
```

- 修改UserDao.xml

```java
<select id="findAll" resultType="user">
         SELECT  * FROM  user
</select>
```

### 4.Mapper

#### 4.1方式一:引入映射文件路径

```xml
<mappers>
     <mapper resource="com/itheima/dao/UserDao.xml"/>
 </mappers>
```

#### 4.2方式二:扫描接口

注: 此方式只能用作:代理开发模式,原始dao方式不能使用.

- 配置单个接口

```xml
<mappers>
 	<mapper class="com.itheima.dao.UserDao"></mapper>
</mappers>
```

- 批量配置

```xml
<mappers>
   <package name="com.itheima.dao"></package>
</mappers>
```


