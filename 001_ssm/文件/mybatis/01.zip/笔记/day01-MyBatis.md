---
typora-copy-images-to: img
---

# day01-MyBatis

## 学习目标

+ 能够了解什么是框架
+ 掌握Mybatis框架开发快速入门
+ 理解自定义Mybatis框架  

## 一,框架概述 

### 1.框架概述

#### 1.1什么是框架 

​	框架（Framework）是整个或部分系统的可重用设计，表现为一组抽象构件及构件实例间交互的方法;另一种定义认为，框架是可被应用开发者定制的应用骨架。前者是从应用方面而后者是从目的方面给出的定义。

​	简而言之，框架是软件(系统)的半成品，框架封装了很多的细节，使开发者可以使用简单的方式实现功能,大大提高开发效率。 

​	开发好比表演节目, 开发者好比演员, 框架好比舞台. 我们作为开发者(演员)需要去搭建舞台(框架)吗? 我们就可以在基于框架开发系统

#### 1.2框架要解决的问题 

​	框架要解决的最重要的一个问题是技术整合的问题，在 J2EE 的 框架中，有着各种各样的技术，不同的软件企业需要从J2EE 中选择不同的技术，这就使得软件企业最终的应用依赖于这些技术，技术自身的复杂性和技术的风险性将会直接对应用造成冲击。而应用是软件企业的核心，是竞争力的关键所在，因此应该将应用自身的设计和具体的实现技术解耦。这样，软件企业的研发将集中在应用的设计上，而不是具体的技术实现，技术实现是应用的底层支撑，它不应该直接对应用产生影响。

​	 框架一般处在低层应用平台（如 J2EE）和高层业务逻辑之间的中间层。

#### 1.3分层开发下的常见框架 

​	通过分层更好的实现了各个部分的职责，在每一层将再细化出不同的框架，分别解决各层关注的问题。

![img](img/tu_14.png)

### 2.JDBC 编程的分析

#### 2.1jdbc 程序的回顾 

+ 注册驱动				    
+ 获得连接                            
+ 创建预编译sql语句对象    
+ 设置参数, 执行
+ 处理结果
+ 释放资源

```java
    public static void main(String[] args) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        try {
            //1.加载数据库驱动
            Class.forName("com.mysql.jdbc.Driver");
            //2.通过驱动管理类获取数据库链接
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/mybatis?characterEncoding=utf-8", "root", "123456");
            //3.定义 sql 语句 ?表示占位符
            String sql = "select * from user where username = ?";
            //4.获取预处理 statement
            preparedStatement = connection.prepareStatement(sql);
            //5.设置参数，第一个参数为 sql 语句中参数的序号（从 1 开始），第二个参数为设置的参数值
            preparedStatement.setString(1, "王五");
            //6.向数据库发出 sql 执行查询，查询出结果集
            resultSet = preparedStatement.executeQuery();
            //7.遍历查询结果集
            while (resultSet.next()) {
                System.out.println(resultSet.getString("id") + "
                        "+resultSet.getString(" username"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
		//8.释放资源
            if (resultSet != null) {
                try {
                    resultSet.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (preparedStatement != null) {
                try {
                    preparedStatement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }
```

#### 2.2jdbc 问题分析 

1. 数据库链接创建、释放频繁造成系统资源浪费从而影响系统性能，如果使用数据库链接池可解决此问题。
2. Sql 语句在代码中硬编码，造成代码不易维护，实际应用 sql 变化的可能较大， sql 变动需要改变java 代码。 
3. 使用 preparedStatement 向占有位符号传参数存在硬编码，因为 sql 语句的 where 条件不一定，可能多也可能少，修改 sql 还要修改代码，系统不易维护。
4. 对结果集解析存在硬编码（查询列名）， sql 变化导致解析代码变化，系统不易维护，如果能将数据库记录封装成 pojo 对象解析比较方便 

### 3,MyBatis框架概述  

​	mybatis 是一个优秀的基于 java 的持久层框架，它内部封装了 jdbc，==使开发者只需要关注 sql 语句本身==，而不需要花费精力去处理加载驱动、创建连接、创建 statement 等繁杂的过程。

​	mybatis 通过==xml 或注解==的方式将要执行的各种statement 配置起来，并通过java 对象和statement 中sql的动态参数进行映射生成最终执行的 sql 语句，最后由 mybatis 框架执行 sql并将结果映射为 java 对象并返回。

​	采用 ORM 思想解决了实体和数据库映射的问题，对jdbc 进行了封装，屏蔽了jdbc api 底层访问细节，使我们不用与 jdbc api打交道，就可以完成对数据库的持久化操作。

官网: http://www.mybatis.org/mybatis-3/

## 二,Mybatis 入门

### 1.准备工作

+ 数据库

```sql
CREATE DATABASE mybatis_day01;
USE mybatis_day01;
CREATE TABLE t_user(
		uid int PRIMARY KEY auto_increment,
		username varchar(40),
	 	sex varchar(10),
		birthday date,
		address varchar(40)
);

INSERT INTO `t_user` VALUES (null, 'zs', '男', '2018-08-08', '北京');
INSERT INTO `t_user` VALUES (null, 'ls', '女', '2018-08-30', '武汉');
INSERT INTO `t_user` VALUES (null, 'ww', '男', '2018-08-08', '北京');
```

### 2.MyBatis快速入门

![img](img/tu_10.png)

需求: 查询所有的用户, 封装到List集合

步骤:

1. 创建Maven工程(jar),导入坐标
2. 创建pojo
3. 创建Dao接口,定义方法
4. 创建Dao映射文件
5. 创建MyBatis核心配置文件
6. 编写java代码测试



#### 2.1创建Maven工程(jar)导入坐标

```xml
  <dependencies>
    <!--MyBatis坐标-->
    <dependency>
      <groupId>org.mybatis</groupId>
      <artifactId>mybatis</artifactId>
      <version>3.4.5</version>
    </dependency>
    <!--mysql驱动-->
    <dependency>
      <groupId>mysql</groupId>
      <artifactId>mysql-connector-java</artifactId>
      <version>5.1.6</version>
    </dependency>
  	<!--单元测试-->
    <dependency>
      <groupId>junit</groupId>
      <artifactId>junit</artifactId>
      <version>4.10</version>
      <scope>test</scope>
    </dependency>
  </dependencies>
```

#### 2.2创建User实体类

+ User .java

```java
public class User implements Serializable{
    private int uid; //用户id
    private String username;// 用户姓名
    private String sex;// 性别
    private Date birthday;// 生日
    private String address;// 地址
	
}
```

#### 2.3创建 UserDao 接口

- UserDao 接口就是我们的持久层接口（也可以写成 UserMapper) .我们就写成UserDao ,具体代码如下： 

```java
public interface UserDao {
    public List<User> findAll();
}
```

#### 2.5创建 UserDao.xml 映射文件

注意:  该文件要放在com/itheima/dao里面, 不要写成com.itheima.dao

 ![1544705827942](img/1544705827942.png)

```xml
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE mapper
        PUBLIC "-//mybatis.org//DTD Mapper 3.0//EN"
        "http://mybatis.org/dtd/mybatis-3-mapper.dtd">
<!--namespace属性: 接口类的全限定名-->
<mapper namespace="com.itheima.dao.UserDao">
    <!--select标签: 查询
        id属性: 方法名
        resultType属性: 写方法返回值类型(如果是list,直接写实体类的全限定名)
        标签体: sql语句
    -->
    <select id="findAll" resultType="com.itheima.bean.User">
        select * from t_user;
    </select>
</mapper>
```

#### 2.4创建 SqlMapConfig.xml 配置文件

```xml
<?xml version="1.0" encoding="UTF-8" ?>
<!DOCTYPE configuration
        PUBLIC "-//mybatis.org//DTD Config 3.0//EN"
        "http://mybatis.org/dtd/mybatis-3-config.dtd">
<configuration>

    <!--配置连接数据库的环境 default:指定使用哪一个环境-->
    <environments default="a">
        <environment id="development">
            <!--配置事务,MyBatis事务用的是jdbc-->
            <transactionManager type="JDBC"/>
            <!--配置连接池, POOLED:使用连接池(mybatis内置的); UNPOOLED:不使用连接池-->
            <dataSource type="POOLED">
                <property name="driver" value="com.mysql.jdbc.Driver"/>
                <property name="url" value="jdbc:mysql://localhost:3306/mybatis_day01?characterEncoding=utf-8"/>
                <property name="username" value="root"/>
                <property name="password" value="123456"/>
            </dataSource>
        </environment>
        <environment id="a">
            <!--配置事务,MyBatis事务用的是jdbc-->
            <transactionManager type="JDBC"/>
            <!--配置连接池, POOLED:使用连接池(mybatis内置的); UNPOOLED:不使用连接池-->
            <dataSource type="POOLED">
                <property name="driver" value="com.mysql.jdbc.Driver"/>
                <property name="url" value="jdbc:mysql://localhost:3306/mybatis_day02?characterEncoding=utf-8"/>
                <property name="username" value="root"/>
                <property name="password" value="123456"/>
            </dataSource>
        </environment>
    </environments>

    <mappers>
        <!--引入映射文件; resource属性: 映射文件的路径-->
        <mapper resource="com/itheima/dao/UserDao.xml"/>
    </mappers>
</configuration>
```

#### 2.6测试

```java
public class DbTest {
    @Test
    public void fun01() throws Exception {
        //1. 读取SqlMapConfig.xml获得输入流
        InputStream is = Resources.getResourceAsStream("SqlMapConfig.xml");
        //2.创建SqlSessionFactory
        SqlSessionFactoryBuilder builder = new SqlSessionFactoryBuilder();
        SqlSessionFactory sqlSessionFactory = builder.build(is);
        //3. 获得SqlSession
        SqlSession sqlSession = sqlSessionFactory.openSession();
        //4.获得UserDao代理对象
        UserDao userDao = sqlSession.getMapper(UserDao.class);
        //5.调用方法
        List<User> list = userDao.findAll();
        System.out.println(list);
        //6.释放资源
        sqlSession.close();
    }
}
```





## 三,自定义 Mybatis 框架  

![img](img/tu_18.png)

### 1.自定义MyBatis准备

#### 1.1创建 Maven 工程  

+ 复制MyBatis入门中的Maven工程
+ 在pom.xml引入坐标(去掉MyBatis, 添加C3P0,DOM4J,XPATH), 去掉mybatis坐标后,发现单元测试里面报错了. 那么下面我们就来开始自定义MyBatis框架

```xml
<dependencies>

    <!--mysql驱动-->
    <dependency>
      <groupId>mysql</groupId>
      <artifactId>mysql-connector-java</artifactId>
      <version>5.1.6</version>
    </dependency>
    <!-- C3P0 -->
    <dependency>
      <groupId>c3p0</groupId>
      <artifactId>c3p0</artifactId>
      <version>0.9.1.2</version>
    </dependency>
    <!-- 解析 xml 的 dom4j -->
    <dependency>
      <groupId>dom4j</groupId>
      <artifactId>dom4j</artifactId>
      <version>1.6.1</version>
    </dependency>
    <!-- dom4j 的依赖包 jaxen -->
    <dependency>
      <groupId>jaxen</groupId>
      <artifactId>jaxen</artifactId>
      <version>1.1.6</version>
    </dependency>

    <!--单元测试-->
    <dependency>
      <groupId>junit</groupId>
      <artifactId>junit</artifactId>
      <version>4.10</version>
      <scope>test</scope>
    </dependency>
  </dependencies>
```

#### 1.2思路分析

![img](img/tu_11.png)

### 2.基于XM方式定义 Mybatis 框架 

#### 2.1创建Resources.java

```java
package com.itheima.mybatis.io;

import java.io.InputStream;


public class Resources {
    /**
     * 读取classpath下面的文件,转成字节输入流
     * @param path
     * @return
     */
    public static InputStream getResourceAsStream(String path) {
        InputStream is = Resources.class.getClassLoader().getResourceAsStream(path);
        return  is;
    }
}
```

#### 2.2使用建造者模式创建SqlSessionFactoryBuilder

##### 2.2.1概述

- 创建者模式介绍

![img](img/tu_8.png)

​	作用: 在用户不知道对象的建造过程和细节的情况下就可以直接创建复杂的对象。

- 具体设计模式的模型图如下  

![img](img/tu_9.png)

##### 2.2.2 SqlSessionFactoryBuilder代码

```java
package com.itheima.mybatis;

import com.itheima.mybatis.defaults.DefaultSqlSessionFactory;

import java.io.InputStream;

public class SqlSessionFactoryBuilder {

    /**
     * 根据字节输入流, 构建SqlSessionFactory
     * @param is
     * @return
     */
    public SqlSessionFactory build(InputStream is) {
        DefaultSqlSessionFactory sqlSessionFactory = new DefaultSqlSessionFactory();
        sqlSessionFactory.setConfig(is);
        return  sqlSessionFactory;
    }
}
```

#### 2.2使用工厂模式创建SqlSessionFactory 

##### 2.2.1概述

+ 工厂模式介绍

![img](img/tu_5.png)

+ 工厂模式的原理如下图 

![img](img/tu_6.png)

##### 2.2.2SqlSessionFactory代码

+ SqlSessionFactory接口

```java
package com.itheima.mybatis;

public interface SqlSessionFactory {

    /**
     * 通过工厂来创建Session对象
     * @return
     */
    SqlSession openSession();
}
```

+ DefautlSqlSessionFactory

```java
package com.itheima.mybatis.defaults;

import com.itheima.mybatis.Configuration;
import com.itheima.mybatis.SqlSession;
import com.itheima.mybatis.SqlSessionFactory;
import com.itheima.mybatis.utils.XmlConfigUtils;

import java.io.InputStream;

/**
 * SqlSessionFactory的实现类
 */
public class DefaultSqlSessionFactory implements SqlSessionFactory {


    private InputStream config;//配置文件的输入流

    public void setConfig(InputStream config) {
        this.config = config;
    }

    /**
     * 获得SqlSession
     *
     * @return
     */
    @Override
    public SqlSession openSession() {
        DefaultSqlSession sqlSession = new DefaultSqlSession();
        //加载配置文件, 给SqlSession赋值
        Configuration configuration = XmlConfigUtils.parseXml(config);
        sqlSession.setConfiguration(configuration);
        return sqlSession;
    }
}

```

> 拷贝XmlConfigUtils工具类到工程里面

#### 2.3配置文件对应的配置类分析

##### 2.3.1映射文件和Mapper分析

![img](img/tu_16.png)

```java
public class Mapper {
    private String sql;
    private String resultType;


    public void setSql(String sql) {
        this.sql = sql;
    }

    public void setResultType(String resultType) {
        this.resultType = resultType;
    }

    public String getSql() {
        return sql;
    }

    public String getResultType() {
        return resultType;
    }
}

```

##### 2.3.2核心配置文件和Configuration

![img](img/tu_17.png)

```java
public class Configuration {
    private String driver;
    private String url;
    private String username;
    private String password;

    private boolean usePool;

    private Map<String,Mapper> mappers = new HashMap<String,Mapper>();

    public String getDriver() {
        return driver;
    }

    public void setDriver(String driver) {
        this.driver = driver;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public boolean isUsePool() {
        return usePool;
    }

    public void setUsePool(boolean usePool) {
        this.usePool = usePool;
    }

    public void setMappers(Map<String,Mapper> mappers) {
        this.mappers.putAll(mappers);
    }

    public Map<String, Mapper> getMappers() {
        return mappers;
    }
}
```

#### 2.4使用代理模式编写 ProxyMethodInvocationHandler类 

##### 2.4.1代理模式回顾

​	代理模式分为静态和动态代理。 静态代理，我们通常都很熟悉。有一个写好的代理类，实现与要代理的类的一个共同的接口，目的是为了约束也为了安全。具体不再多说。

​	这里主要想说的是关于动态代理。我们知道静态代理若想代理多个类，实现扩展功能，那么它必须具有多个代理类分别取代理不同的实现类。这样做的后果是造成太多的代码冗余。那么我们会思考如果做，才能既满足需求，又没有太多的冗余代码呢？ ——————动态代理。通过前面的课程我们已经学过了基于 JDK 的动态代理实现方式，今天我们就会使用 JDK 动态代理方式来编写MapperProxyFactory 类。

![img](img/tu_7.png) 

##### 2.4.2 编写SqlSession和DefaultSqlSession

​	基本上任何持久层框架都通过自定义的类来封装JDBC,这里我们就采取SqlSession来封装. 

​	SqlSession的作用返回Mapper的代理对象

+ SqlSession接口

```java
package com.itheima.mybatis;

public interface SqlSession {
    /**
     * 根据Dao的字节码产生代理对象
     * @param daoClass
     * @param <T>
     * @return
     */
    <T>T getMapper(Class<T> daoClass);

    /**
     * 释放资源
     */
    void close();

}

```

+ DefaultSqlSession实现类

```java
package com.itheima.mybatis.defaults;

import com.alibaba.druid.pool.DruidDataSource;
import com.itheima.mybatis.Configuration;
import com.itheima.mybatis.SqlSession;
import com.itheima.mybatis.proxy.MethodProxyInvocationHandler;

import java.lang.reflect.Proxy;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DefaultSqlSession implements SqlSession {

    private Configuration configuration;//配置对象
    private Connection connection;//连接对象

    /**
     * 获得Dao的代理对象
     *
     * @param daoClass
     * @return
     */
    @Override
    public <T> T getMapper(Class<T> daoClass) {
        return (T) Proxy.newProxyInstance(daoClass.getClassLoader(),
                new Class[]{daoClass},new MethodProxyInvocationHandler(getConnection(),configuration.getMappers()));
    }

    /**
     * 释放资源
     */
    @Override
    public void close() {
        if(connection != null){
            try {
                connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public void setConfiguration(Configuration configuration) {
        this.configuration = configuration;
    }

    public Connection getConnection() {
        if(!configuration.isUsePool()){
            try {
                Class.forName(configuration.getDriver());
                connection = DriverManager.getConnection(configuration.getUrl(),
                        configuration.getUsername(),configuration.getPassword());

            } catch (Exception e) {
                e.printStackTrace();
            }
        }else{
            try {
                DruidDataSource dataSource = new DruidDataSource();
                dataSource.setDriverClassName(configuration.getDriver());
                dataSource.setUrl(configuration.getUrl());
                dataSource.setUsername(configuration.getUsername());
                dataSource.setPassword(configuration.getPassword());
                connection = dataSource.getConnection();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return connection;
    }
}
```

##### 2.4.3编写 ProxyMethodInvocationHandler类 

```java
package com.itheima.mybatis.proxy;

import com.itheima.mybatis.mapper.Mapper;
import com.itheima.mybatis.utils.ResultUtils;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class MethodProxyInvocationHandler implements InvocationHandler {

    private  Map<String, Mapper> mappers;
    private  Connection connection;

    public MethodProxyInvocationHandler(Connection connection, Map<String, Mapper> mappers) {
        this.connection = connection;
        this.mappers = mappers;
    }

    @Override
    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        //1. 获得方法名(id)
        String methodName = method.getName();
        //2. 获得当前方法所在类的全限定名(namespace)
        String className = method.getDeclaringClass().getName();
        //3. 获得mapper对象
        Mapper mapper = mappers.get(className + "." + methodName);
        //4.获得sql语句和结果类型
        String sql = mapper.getSql();
        String resultType = mapper.getResultType();
        //5创建预编译sql语句对象
        preparedStatement = connection.prepareStatement(sql);
        //6.执行
        resultSet = preparedStatement.executeQuery();
        List list = ResultUtils.handleResult(resultSet, resultType);
        return list;
    }
}

```

> 拷贝ResultUtils工具类到工程

#### 2.4测试

### 3.基于注解方式定义 Mybatis 框架

#### 3.1定义注解Select

```java
package com.itheima.mybatis.annotation;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

@Retention(RetentionPolicy.RUNTIME)
public @interface Select {
    String value();
}
```

#### 3.2在UserDao上使用注解

```java
public interface UserDao {
    @Select("select * from t_user")
    List<User> findAll();
}
```

#### 3.3把XmlConfigUtils工具类注解部分取消注释

#### 3.4修改SqlMapConfig.xml

![img](img/tu_13.png)



## 四,附录

### 1.泛型的反射

- 泛型的基本的术语   

```
以ArrayList<E>为例: 

ArrayList<E>		：<> 念为typeof
ArrayList<E>		：E类型参数变量
ArrayList<String>	：String，实际类型参数
ArrayList<String>	：参数化类型 ParameterizedType


eg: List<User>;  参数化类型, 就是获得参数化类型里面的实际类型参数


Type returnType = method.getGenericReturnType(); //  List<User>
ParameterizedType parameterizedType = (ParameterizedType) returnType;//List<User>

Class returnTypeClass = (Class) parameterizedType.getActualTypeArguments()[0];//获得实际类型参数  
```

- 相关的API

```
* Type[] getGenericInterfaces();		--获得带有泛型的接口
* Type getGenericSuperClass();		    --获得带有泛型的父类
```